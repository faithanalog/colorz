Calculator version of http://z80.ukl.me/colorz/

How to install:
* Install DoorsCSE 8.1 or later from http://dcs.cemetech.net

* Move COLORZ.8xp to your calculator

* Run COLORZ from DoorsCSE or the programs list


Instructions:
* Use the arrow keys to move.

* Collect all the gold. There are a total of 9 collectible gold pieces.

* Reach the end of the game.

* Because this is a puzzle game, I will not go into detail about the puzzle
  mechanics. Rest assured that if you think you are stuck, you are not
  stuck. You just haven't found the way out yet.

When the game is over, an animation will play, and then all the gold pieces
you have collected will be displayed. The game will then restart.

If you have trouble and want to cheat, there's a walkthrough here:
https://www.youtube.com/watch?v=uLtugOob318.

Backstory:
You are a scientist trapped in a laboratory that has been attacked by aliens!
Find a way to get on board the alien ship and blow it up from the inside.
